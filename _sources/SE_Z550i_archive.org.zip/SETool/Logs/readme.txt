session log will be placed here
